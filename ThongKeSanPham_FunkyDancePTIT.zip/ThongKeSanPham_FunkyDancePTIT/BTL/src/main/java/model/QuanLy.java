package model;

public class QuanLy extends ThanhVien{

}
